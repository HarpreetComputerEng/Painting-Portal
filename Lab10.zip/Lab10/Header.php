<!DOCTYPE html>
<html>
<head>
    <title>Lab 10 - PHP, AJAX, and XML</title>
</head>
<body style="margin:0; font-family:Arial, sans-serif;">
    <div style="background-color:#e6f7f9; text-align:center; padding:10px;">
        <div><strong>Computer Engineering Technology</strong></div>
        <div>Lab 10 - PHP, AJAX, and XML</div>
    </div>
    <div style="background-color:#e6f7f9; text-align:right; padding:5px;">
        <?php include 'Menu.php'; ?>
    </div>
    <div style="background-color:#faebd7; min-height:500px; padding:10px;">
