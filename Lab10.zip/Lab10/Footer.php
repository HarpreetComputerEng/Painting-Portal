</div> <!-- End of content div -->
<div style="background-color: #333; color: white; padding: 10px; text-align: center;">
    Student Number: 041127993 | First Name: Harpreet | Last Name: Singh | Email: harp0183@algonquinlive.com
</div>
</body>
</html>
